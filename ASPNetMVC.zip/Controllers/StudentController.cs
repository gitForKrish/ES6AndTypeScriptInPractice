﻿using ContosoUniversity.DAL;
using ContosoUniversity.Models;
using System.Linq;
using System.Web.Mvc;

namespace ContosoUniversity.Controllers
{
    public class StudentController : Controller
    {
        public SchoolContext db = new SchoolContext();
        
        // GET: Student
        public ActionResult Index()
        {
            return View(db.Students.ToList());
        }

        // Get: Student/Create
        public ActionResult Create()
        {
            return View();
        }

        // Post: Student/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,LastName,FirstMidName,EnrollmentDate")]Student student)
        {
            if (ModelState.IsValid)
            {
                db.Students.Add(student);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(student);
        }
    }
}